# X64 Secure Boot Defaults
 Secure Boot Defaults

This external dependency contains the default values suggested by microsoft the KEK, DB, and DBX UEFI variables.

Additionally, it contains an optional shared PK certificate that may be used as the root of trust for the system.
The shared PK certificate is an offering from Microsoft. Instead of a original equipment manufacturer (OEM)
managed PK, an OEM may choose to use the shared PK certificate managed by Microsoft. Practically, this may be
useful as default on non production code provided to an OEM by an independent vendor (IV).

1. The PK (Platform Key) is a single certificate that is the root of trust for the system. This certificate is used
    to verify the KEK.
2. The KEK (Key Exchange Key) is a list of certificates that verify the signature of other keys attempting to update
   the DB and DBX.
3. The DB (Signature Database) is a list of certificates that verify the signature of a binary attempting to execute
   on the system.
4. The DBX (Forbidden Signature Database) is a list of signatures that are forbidden from executing on the system.

Please review [Microsoft's documentation](https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/windows-secure-boot-key-creation-and-management-guidance?view=windows-11#15-keys-required-for-secure-boot-on-all-pcs)
for more information on key requirements if appending to the defaults provided in this external dependency.

## Folder Layout

### Artifacts

This folder contains the defaults in a EFI Signature List Format broken up by architecture. This format is used by the
UEFI firmware to initialize the secure boot variables. These files are in the format described by
[EFI_SIGNATURE_DATA](https://uefi.org/specs/UEFI/2.10/32_Secure_Boot_and_Driver_Signing.html?highlight=authenticated%20variable#efi-signature-data)

## PK

Contains the Microsoft PK to enable signature database updates and binary execution.

Files Included:

* PreSignedObjects/PK/Certificate/WindowsOEMDevicesPK.der

## KEK

Contains the Microsoft KEKs to enable signature database updates and binary execution.

Files Included:

* PreSignedObjects/KEK/Certificates/microsoft corporation kek 2k ca 2023.der
  * <https://go.microsoft.com/fwlink/?linkid=2239775>

## DB

Contains only Microsoft certificates to verify binaries before execution. More than Default3PDb.

Files Included:

* PreSignedObjects/DB/Certificates/windows uefi ca 2023.der
  * <https://go.microsoft.com/fwlink/?linkid=2239776>
* PreSignedObjects/DB/Certificates/microsoft option rom uefi ca 2023.der
  * <http://www.microsoft.com/pkiops/certs/microsoft%20option%20rom%20uefi%20ca%202023.crt>

## DBX

Contains a list of revoked certificates that will not execute on this system. Filtered per Architecture (ARM, Intel).

Files Included:

* PreSignedObjects/DBX/dbx_info_msft_latest.json

---

## License

Terms of Use for Microsoft Secure Boot Objects Secure Boot Objects

By downloading the Secure Boot Objects you agree to the following terms
If you do not accept them do not download or use the Secure Boot Objects

These terms do not provide you with any legal rights to any intellectual
property in any Microsoft product

You may copy and use the Secure Boot Objects for your internal reference
purposes and to design develop and test your software firmware or hardware
as applicable and you may distribute the Secure Boot Objects to end users
solely as part of the distribution of a software product or
as part of the distribution of updates to a software product
and you may distribute the Secure Boot Objects to end users or through your
distribution channels solely as embodied in a firmware product or hardware
product that embodies nontrivial additional functionality Without limiting the
foregoing copying or reproduction of the Secure Boot Objects to any other
server or location for further reproduction or redistribution on a standalone
basis is expressly prohibited

If you are engaged in the business of developing and commercializing hardware
products that include the UEFI standard
available at https://uefi.org/specifications you may copy and use the Secure
Boot Objects for your internal reference purposes and to design develop and
test your software and you may distribute the Secure Boot Objects end users
solely as part of the distribution of a software product or
as part of the distribution of updates to a software product
Without limiting the foregoing copying or reproduction of the Secure Boot
Objects to any other server or location for further reproduction or
redistribution on a standalone basis is expressly prohibited
The Secure Boot Objects are provided asis The information contained in the
Secure Boot Objects may change without notice  Microsoft does not represent
that the Secure Boot Objects is error free and you bear the entire risk of
using it

NEITHER MICROSOFT NOR UEFI MAKES ANY WARRANTIES EXPRESS OR IMPLIED
WITH RESPECT TO THE SECURE BOOT OBJECTS AND MICROSOFT AND UEFI EACH EXPRESSLY
DISCLAIMS ALL OTHER EXPRESS IMPLIED OR STATUTORY WARRANTIES THIS INCLUDES
THE WARRANTIES OF MERCHANTABILITY FITNESS FOR A PARTICULAR PURPOSE TITLE AND
NONINFRINGEMENT

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW IN NO EVENT SHALL MICROSOFT
OR UEFI BE LIABLE FOR ANY SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY
DAMAGES WHATSOEVER ARISING OUT OF OR IN CONNECTION WITH THE USE OR DISTRIBUTION
OF THE SECURE BOOT OBJECTS WHETHER IN AN ACTION OF CONTRACT NEGLIGENCE OR
OTHER TORTIOUS ACTION

YOU AGREE TO RELEASE MICROSOFT INCLUDING ITS AFFILIATES CONTRACTORS AGENTS
EMPLOYEES LICENSEES AND ASSIGNEES AND UEFI INCLUDING ITS AFFILIATES
CONTRACTORS AGENTS EMPLOYEES LICENSEES AND SUCCESSORS FROM ANY AND ALL
CLAIMS OR LIABILITY ARISING OUT OF YOUR USE OR DISTRIBUTION OF THE SECURE
BOOT OBJECTS AND ANY RELATED INFORMATION
